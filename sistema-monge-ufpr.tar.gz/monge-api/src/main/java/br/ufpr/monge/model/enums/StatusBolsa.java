package br.ufpr.monge.model.enums;

public enum StatusBolsa {
    ATIVA,
    INATIVA,
    SUSPENSA,
    CONCLUIDA
}