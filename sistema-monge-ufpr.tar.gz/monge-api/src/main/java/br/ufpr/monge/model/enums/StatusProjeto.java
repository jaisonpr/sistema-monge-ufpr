package br.ufpr.monge.model.enums;

public enum StatusProjeto {
    EM_ELABORACAO,
    ATIVO,
    CONCLUIDO,
    CANCELADO
}