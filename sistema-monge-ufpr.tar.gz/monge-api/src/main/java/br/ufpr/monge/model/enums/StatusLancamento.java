package br.ufpr.monge.model.enums;

public enum StatusLancamento {
    PENDENTE,
    APROVADO,
    REPROVADO,
    JUSTIFICADO
}