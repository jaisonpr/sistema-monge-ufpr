package br.ufpr.monge.model.enums;

public enum StatusVinculo {
    ATIVO,
    INATIVO,
    CONCLUIDO
}