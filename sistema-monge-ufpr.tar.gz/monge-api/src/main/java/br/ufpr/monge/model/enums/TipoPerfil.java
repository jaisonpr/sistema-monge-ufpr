package br.ufpr.monge.model.enums;

public enum TipoPerfil {
    ADMIN,
    ORIENTADOR,
    BOLSISTA
}