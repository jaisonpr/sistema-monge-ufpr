package br.ufpr.monge.model.enums;

public enum TipoNotificacao {
    LANCAMENTO_PENDENTE,
    LANCAMENTO_APROVADO,
    LANCAMENTO_REPROVADO,
    AVISO_GERAL
}